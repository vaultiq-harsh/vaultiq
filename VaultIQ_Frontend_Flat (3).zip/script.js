function startVaultIQ() {
  alert("Redirecting to trusted AI earning method...");
  window.location.href = "https://tool-referral-link-here.com";
}