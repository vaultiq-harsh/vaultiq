# VaultIQ - Trusted AI Earning Platform
This is the frontend of VaultIQ — an AI-powered platform where users get earning methods referred by ChatGPT.